package com.meu.tclauncher.data

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.media.tv.TvContract
import android.media.tv.TvInputManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

data class AppItem(
    val pkg: String,
    val label: String,
    val icon: ImageBitmap?,
    val isBanner: Boolean,
    val intent: Intent,
)

data class ShortcutItem(val label: String, val intent: Intent)

data class InputItem(val label: String, val intent: Intent)

class Repository(private val context: Context) {

    private fun Drawable.toImage(w: Int, h: Int): ImageBitmap? =
        try { toBitmap(w, h).asImageBitmap() } catch (e: Throwable) { null }

    /** Todos os apps instalados que aparecem no launcher da TV (leanback) ou no launcher comum. */
    fun loadApps(): List<AppItem> {
        val pm = context.packageManager
        val result = LinkedHashMap<String, AppItem>()

        fun collect(category: String) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == context.packageName || result.containsKey(pkg)) continue
                val banner = try { ri.activityInfo.loadBanner(pm) } catch (e: Throwable) { null }
                val drawable = banner ?: ri.loadIcon(pm)
                val intent = pm.getLeanbackLaunchIntentForPackage(pkg)
                    ?: pm.getLaunchIntentForPackage(pkg)
                    ?: continue
                result[pkg] = AppItem(
                    pkg = pkg,
                    label = ri.loadLabel(pm).toString(),
                    icon = drawable?.toImage(320, 180),
                    isBanner = banner != null,
                    intent = intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            }
        }
        collect(Intent.CATEGORY_LEANBACK_LAUNCHER)
        collect(Intent.CATEGORY_LAUNCHER)
        return result.values.sortedBy { it.label.lowercase() }
    }

    /** Entradas da TV (HDMI, AV, TV ao vivo) pelo framework oficial TvInputManager. */
    fun loadInputs(): List<InputItem> {
        return try {
            val tim = context.getSystemService(Context.TV_INPUT_SERVICE) as TvInputManager
            tim.tvInputList.mapNotNull { info ->
                val label = info.loadLabel(context)?.toString() ?: return@mapNotNull null
                val intent = if (info.isPassthroughInput) {
                    Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(info.id))
                } else {
                    context.packageManager
                        .getLeanbackLaunchIntentForPackage(info.serviceInfo.packageName)
                        ?: return@mapNotNull null
                }
                InputItem(label, intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        } catch (e: Throwable) {
            emptyList()
        }
    }

    fun shortcuts(): List<ShortcutItem> = listOf(
        ShortcutItem("Configurações", Intent(Settings.ACTION_SETTINGS)),
        ShortcutItem("Wi-Fi / Rede", Intent(Settings.ACTION_WIFI_SETTINGS)),
        ShortcutItem("Bluetooth", Intent(Settings.ACTION_BLUETOOTH_SETTINGS)),
        ShortcutItem("Tela", Intent(Settings.ACTION_DISPLAY_SETTINGS)),
        ShortcutItem("Som", Intent(Settings.ACTION_SOUND_SETTINGS)),
        ShortcutItem("Todos os apps", Intent(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS)),
        ShortcutItem("Trocar launcher padrão", Intent(Settings.ACTION_HOME_SETTINGS)),
    ).map { it.copy(intent = it.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    fun appInfoIntent(pkg: String) =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun uninstallIntent(pkg: String) =
        Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
