package com.meu.tclauncher

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.meu.tclauncher.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LauncherViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repository(app)
    private val store = PrefsStore(app)

    val prefs: StateFlow<LauncherPrefs> =
        store.flow.stateIn(viewModelScope, SharingStarted.Eagerly, LauncherPrefs())

    private val _apps = MutableStateFlow<List<AppItem>>(emptyList())
    val apps: StateFlow<List<AppItem>> = _apps

    private val _inputs = MutableStateFlow<List<InputItem>>(emptyList())
    val inputs: StateFlow<List<InputItem>> = _inputs

    val shortcuts = repo.shortcuts()

    fun refresh() {
        viewModelScope.launch {
            val (a, i) = withContext(Dispatchers.Default) { repo.loadApps() to repo.loadInputs() }
            _apps.value = a
            _inputs.value = i
        }
    }

    fun launch(context: Context, intent: Intent) {
        try { context.startActivity(intent) } catch (e: Throwable) { /* app indisponível */ }
    }

    fun appInfo(context: Context, pkg: String) = launch(context, repo.appInfoIntent(pkg))
    fun uninstall(context: Context, pkg: String) = launch(context, repo.uninstallIntent(pkg))

    fun edit(block: (LauncherPrefs) -> LauncherPrefs) {
        viewModelScope.launch { store.update(block) }
    }

    fun toggleFavorite(pkg: String) = edit {
        it.copy(favorites = if (pkg in it.favorites) it.favorites - pkg else it.favorites + pkg)
    }

    fun moveFavorite(pkg: String, delta: Int) = edit {
        val list = it.favorites.toMutableList()
        val i = list.indexOf(pkg)
        val j = i + delta
        if (i >= 0 && j in list.indices) {
            list[i] = list[j].also { list[j] = list[i] }
        }
        it.copy(favorites = list)
    }

    fun toggleHidden(pkg: String) = edit {
        it.copy(hidden = if (pkg in it.hidden) it.hidden - pkg else it.hidden + pkg)
    }

    /** Nome vazio remove o apelido e volta ao nome original do app. */
    fun rename(pkg: String, name: String) = edit {
        val n = name.trim()
        it.copy(renames = if (n.isEmpty()) it.renames - pkg else it.renames + (pkg to n))
    }

    fun moveSection(id: String, delta: Int) = edit {
        val list = it.sections.toMutableList()
        val i = list.indexOf(id)
        val j = i + delta
        if (i >= 0 && j in list.indices) {
            list[i] = list[j].also { list[j] = list[i] }
        }
        it.copy(sections = list)
    }

    fun applyTheme(theme: Theme) = edit { theme.apply(it) }
}
