package com.meu.tclauncher.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meu.tclauncher.LauncherViewModel
import com.meu.tclauncher.data.*

private enum class Page { Main, Hidden, Sections }

@Composable
fun SettingsScreen(vm: LauncherViewModel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val prefs by vm.prefs.collectAsState()
    val apps by vm.apps.collectAsState()
    var page by remember { mutableStateOf(Page.Main) }
    var themeIdx by remember { mutableIntStateOf(-1) }

    BackHandler { if (page != Page.Main) page = Page.Main else onClose() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Throwable) {}
            vm.edit { it.copy(bgImage = uri.toString()) }
        }
    }

    LauncherBackground(prefs) {
        Column(Modifier.fillMaxSize().padding(horizontal = 80.dp, vertical = 32.dp)) {
            Text(
                when (page) {
                    Page.Main -> "Personalizar"
                    Page.Hidden -> "Apps ocultos"
                    Page.Sections -> "Ordem das seções"
                },
                color = Color.White, fontSize = 30.sp,
            )
            Spacer(Modifier.height(16.dp))

            when (page) {
                Page.Hidden -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(apps, key = { it.pkg }) { app ->
                        val hidden = app.pkg in prefs.hidden
                        FocusButton(
                            (if (hidden) "☐  Oculto — " else "☑  Visível — ") + (prefs.renames[app.pkg] ?: app.label),
                            prefs.accent, Modifier.fillMaxWidth(),
                        ) { vm.toggleHidden(app.pkg) }
                    }
                }

                Page.Sections -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(prefs.sections, key = { it }) { id ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FocusButton(
                                SECTION_NAMES.getValue(id), prefs.accent,
                                Modifier.weight(1f),
                            ) { }
                            FocusButton("▲ Subir", prefs.accent) { vm.moveSection(id, -1) }
                            FocusButton("▼ Descer", prefs.accent) { vm.moveSection(id, 1) }
                        }
                    }
                    item { Option("Voltar", "", prefs) { page = Page.Main } }
                }

                Page.Main -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        Option(
                            "Tema pronto",
                            if (themeIdx < 0) "escolher" else THEMES[themeIdx].name, prefs,
                        ) {
                            themeIdx = (themeIdx + 1) % THEMES.size
                            vm.applyTheme(THEMES[themeIdx])
                        }
                    }
                    item {
                        Option("Cor de destaque", "toque para trocar", prefs) {
                            vm.edit { it.copy(accent = ACCENTS[(ACCENTS.indexOf(it.accent) + 1) % ACCENTS.size]) }
                        }
                    }
                    item {
                        Option("Plano de fundo", BACKGROUNDS[prefs.bgIndex.coerceIn(0, BACKGROUNDS.lastIndex)].first, prefs) {
                            vm.edit { it.copy(bgIndex = (it.bgIndex + 1) % BACKGROUNDS.size) }
                        }
                    }
                    item {
                        Option("Imagem de fundo", if (prefs.bgImage == null) "nenhuma — escolher" else "definida — trocar", prefs) {
                            try { picker.launch(arrayOf("image/*")) } catch (_: Throwable) {}
                        }
                    }
                    if (prefs.bgImage != null) {
                        item { Option("Remover imagem de fundo", "", prefs) { vm.edit { it.copy(bgImage = null) } } }
                    }
                    item {
                        Option("Tamanho dos cartões", listOf("Pequeno", "Médio", "Grande")[prefs.cardSize], prefs) {
                            vm.edit { it.copy(cardSize = (it.cardSize + 1) % 3) }
                        }
                    }
                    item { Option("Cantos arredondados", onOff(prefs.rounded), prefs) { vm.edit { it.copy(rounded = !it.rounded) } } }
                    item { Option("Mostrar relógio", onOff(prefs.showClock), prefs) { vm.edit { it.copy(showClock = !it.showClock) } } }
                    item { Option("Relógio grande", onOff(prefs.bigClock), prefs) { vm.edit { it.copy(bigClock = !it.bigClock) } } }
                    item { Option("Formato 24 horas", onOff(prefs.clock24), prefs) { vm.edit { it.copy(clock24 = !it.clock24) } } }
                    item { Option("Mostrar entradas da TV (HDMI/AV)", onOff(prefs.showInputs), prefs) { vm.edit { it.copy(showInputs = !it.showInputs) } } }
                    item { Option("Mostrar atalhos do sistema", onOff(prefs.showShortcuts), prefs) { vm.edit { it.copy(showShortcuts = !it.showShortcuts) } } }
                    item { Option("Ordem das seções", "", prefs) { page = Page.Sections } }
                    item { Option("Gerenciar apps ocultos", "${prefs.hidden.size} oculto(s)", prefs) { page = Page.Hidden } }
                    item {
                        Option("Restaurar padrões", "", prefs) {
                            themeIdx = -1
                            vm.edit { LauncherPrefs(favorites = it.favorites, renames = it.renames) }
                        }
                    }
                    item { Option("Voltar", "", prefs, onClose) }
                }
            }
        }
    }
}

private fun onOff(b: Boolean) = if (b) "ligado" else "desligado"

@Composable
private fun Option(title: String, value: String, prefs: LauncherPrefs, onClick: () -> Unit) {
    FocusButton(if (value.isEmpty()) title else "$title:  $value", prefs.accent, Modifier.fillMaxWidth(), onClick)
}
