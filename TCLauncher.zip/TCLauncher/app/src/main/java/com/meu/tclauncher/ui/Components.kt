package com.meu.tclauncher.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.meu.tclauncher.data.BACKGROUNDS
import com.meu.tclauncher.data.LauncherPrefs
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun LauncherBackground(prefs: LauncherPrefs, content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        val (c1, c2) = BACKGROUNDS[prefs.bgIndex.coerceIn(0, BACKGROUNDS.lastIndex)].second
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(c1), Color(c2)))))
        if (prefs.bgImage != null) {
            AsyncImage(
                model = prefs.bgImage,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)))
        }
        content()
    }
}

@Composable
fun ClockView(prefs: LauncherPrefs) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(1000L * (60 - now.second))
        }
    }
    val timeFmt = DateTimeFormatter.ofPattern(if (prefs.clock24) "HH:mm" else "hh:mm a", Locale("pt", "BR"))
    val dateFmt = DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", Locale("pt", "BR"))
    val big = prefs.bigClock
    Column(horizontalAlignment = Alignment.End) {
        Text(
            now.format(timeFmt), color = Color.White,
            fontSize = if (big) 88.sp else 44.sp, fontWeight = FontWeight.Light,
        )
        Text(
            now.format(dateFmt).replaceFirstChar { it.uppercase() },
            color = Color.White.copy(alpha = 0.7f), fontSize = if (big) 24.sp else 16.sp,
        )
    }
}

/** Cartão focável por D-pad: OK = abrir, segurar OK = menu de opções. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Tile(
    label: String,
    icon: ImageBitmap?,
    isBanner: Boolean,
    prefs: LauncherPrefs,
    modifier: Modifier = Modifier,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    val factor = when (prefs.cardSize) { 0 -> 0.8f; 2 -> 1.25f; else -> 1f }
    val width = (176 * factor).dp
    val height = (99 * factor).dp
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.1f else 1f, label = "scale")
    val shape = RoundedCornerShape(if (prefs.rounded) 14.dp else 2.dp)

    Column(modifier.width(width).padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(width, height)
                .scale(scale)
                .onFocusChanged { focused = it.isFocused }
                .clip(shape)
                .background(Color.White.copy(alpha = if (focused) 0.18f else 0.10f))
                .border(if (focused) 3.dp else 0.dp, Color(prefs.accent), shape)
                .combinedClickable(onClick = onClick, onLongClick = onLongClick),
            contentAlignment = Alignment.Center,
        ) {
            if (icon != null) {
                Image(
                    bitmap = icon,
                    contentDescription = label,
                    contentScale = if (isBanner) ContentScale.Crop else ContentScale.Fit,
                    modifier = if (isBanner) Modifier.fillMaxSize() else Modifier.size(height * 0.65f),
                )
            } else {
                Text(label.take(2).uppercase(), color = Color.White, fontSize = 28.sp)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            label,
            color = Color.White.copy(alpha = if (focused) 1f else 0.75f),
            fontSize = 14.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        color = Color.White,
        fontSize = 20.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(start = 48.dp, top = 12.dp, bottom = 2.dp),
    )
}

/** Botão de texto focável simples (usado em menus e configurações). */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FocusButton(text: String, accent: Int, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        modifier
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(10.dp))
            .background(if (focused) Color(accent) else Color.White.copy(alpha = 0.10f))
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp),
    ) {
        Text(text, color = if (focused) Color.Black else Color.White, fontSize = 18.sp)
    }
}
