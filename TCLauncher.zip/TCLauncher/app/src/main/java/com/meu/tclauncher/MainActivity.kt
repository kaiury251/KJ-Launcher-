package com.meu.tclauncher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.meu.tclauncher.ui.HomeScreen
import com.meu.tclauncher.ui.SettingsScreen

class MainActivity : ComponentActivity() {
    private val vm: LauncherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var settings by rememberSaveable { mutableStateOf(false) }
            // Como todo launcher, o botão Voltar na tela inicial não faz nada.
            BackHandler(enabled = !settings) { }
            if (settings) SettingsScreen(vm) { settings = false }
            else HomeScreen(vm) { settings = true }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refresh() // atualiza apps instalados/removidos e entradas
    }
}
