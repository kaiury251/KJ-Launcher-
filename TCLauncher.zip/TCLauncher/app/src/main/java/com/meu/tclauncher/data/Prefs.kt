package com.meu.tclauncher.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore("launcher_prefs")

val DEFAULT_SECTIONS = listOf("inputs", "favorites", "apps", "shortcuts")

val SECTION_NAMES = mapOf(
    "inputs" to "Entradas da TV",
    "favorites" to "Favoritos",
    "apps" to "Todos os apps",
    "shortcuts" to "Atalhos do sistema",
)

data class LauncherPrefs(
    val accent: Int = 0xFF4FC3F7.toInt(),
    val bgIndex: Int = 0,
    val bgImage: String? = null,
    val cardSize: Int = 1, // 0 pequeno, 1 médio, 2 grande
    val showClock: Boolean = true,
    val clock24: Boolean = true,
    val bigClock: Boolean = false,
    val showInputs: Boolean = true,
    val showShortcuts: Boolean = true,
    val rounded: Boolean = true,
    val favorites: List<String> = emptyList(),
    val hidden: Set<String> = emptySet(),
    val renames: Map<String, String> = emptyMap(),
    val sections: List<String> = DEFAULT_SECTIONS,
)

val ACCENTS = listOf(
    0xFF4FC3F7.toInt(), 0xFFFF7043.toInt(), 0xFF66BB6A.toInt(),
    0xFFAB47BC.toInt(), 0xFFFFCA28.toInt(), 0xFFEC407A.toInt(), 0xFFFFFFFF.toInt(),
)

val BACKGROUNDS = listOf(
    "Noite" to (0xFF0B1220.toInt() to 0xFF1B2A49.toInt()),
    "Aurora" to (0xFF0F2027.toInt() to 0xFF2C5364.toInt()),
    "Pôr do sol" to (0xFF2B1055.toInt() to 0xFFD76D77.toInt()),
    "Floresta" to (0xFF0B2B1F.toInt() to 0xFF1F6F4A.toInt()),
    "Grafite" to (0xFF121212.toInt() to 0xFF2A2A2A.toInt()),
    "Preto total" to (0xFF000000.toInt() to 0xFF000000.toInt()),
)

/** Temas prontos: aplicam cor, fundo, tamanho, cantos e relógio de uma vez. */
data class Theme(val name: String, val apply: (LauncherPrefs) -> LauncherPrefs)

val THEMES = listOf(
    Theme("Clássico") { it.copy(accent = ACCENTS[0], bgIndex = 0, bgImage = null, cardSize = 1, rounded = true, bigClock = false) },
    Theme("Cinema") { it.copy(accent = ACCENTS[1], bgIndex = 5, bgImage = null, cardSize = 2, rounded = true, bigClock = false) },
    Theme("Minimalista") { it.copy(accent = ACCENTS[6], bgIndex = 4, bgImage = null, cardSize = 0, rounded = false, bigClock = true) },
    Theme("Natureza") { it.copy(accent = ACCENTS[2], bgIndex = 3, bgImage = null, cardSize = 1, rounded = true, bigClock = true) },
    Theme("Entardecer") { it.copy(accent = ACCENTS[5], bgIndex = 2, bgImage = null, cardSize = 1, rounded = true, bigClock = false) },
)

private fun normalizeSections(saved: List<String>): List<String> =
    saved.filter { it in DEFAULT_SECTIONS }.distinct().let { s -> s + DEFAULT_SECTIONS.filter { it !in s } }

private fun encodeRenames(m: Map<String, String>) =
    m.entries.joinToString("\n") { it.key + "=" + it.value.replace("\n", " ") }

private fun decodeRenames(s: String?): Map<String, String> =
    s?.lines()?.mapNotNull { line ->
        val i = line.indexOf('=')
        if (i > 0 && i < line.lastIndex) line.substring(0, i) to line.substring(i + 1) else null
    }?.toMap() ?: emptyMap()

class PrefsStore(private val context: Context) {
    private object K {
        val accent = intPreferencesKey("accent")
        val bgIndex = intPreferencesKey("bg_index")
        val bgImage = stringPreferencesKey("bg_image")
        val cardSize = intPreferencesKey("card_size")
        val showClock = booleanPreferencesKey("show_clock")
        val clock24 = booleanPreferencesKey("clock24")
        val bigClock = booleanPreferencesKey("big_clock")
        val showInputs = booleanPreferencesKey("show_inputs")
        val showShortcuts = booleanPreferencesKey("show_shortcuts")
        val rounded = booleanPreferencesKey("rounded")
        val favorites = stringPreferencesKey("favorites")
        val hidden = stringSetPreferencesKey("hidden")
        val renames = stringPreferencesKey("renames")
        val sections = stringPreferencesKey("sections")
    }

    private fun Preferences.toPrefs(): LauncherPrefs {
        val d = LauncherPrefs()
        return LauncherPrefs(
            accent = this[K.accent] ?: d.accent,
            bgIndex = this[K.bgIndex] ?: d.bgIndex,
            bgImage = this[K.bgImage],
            cardSize = this[K.cardSize] ?: d.cardSize,
            showClock = this[K.showClock] ?: d.showClock,
            clock24 = this[K.clock24] ?: d.clock24,
            bigClock = this[K.bigClock] ?: d.bigClock,
            showInputs = this[K.showInputs] ?: d.showInputs,
            showShortcuts = this[K.showShortcuts] ?: d.showShortcuts,
            rounded = this[K.rounded] ?: d.rounded,
            favorites = this[K.favorites]?.split(",")?.filter { it.isNotBlank() } ?: emptyList(),
            hidden = this[K.hidden] ?: emptySet(),
            renames = decodeRenames(this[K.renames]),
            sections = normalizeSections(this[K.sections]?.split(",") ?: emptyList()),
        )
    }

    val flow: Flow<LauncherPrefs> = context.store.data.map { it.toPrefs() }

    suspend fun update(block: (LauncherPrefs) -> LauncherPrefs) {
        context.store.edit { p ->
            val n = block(p.toPrefs())
            p[K.accent] = n.accent
            p[K.bgIndex] = n.bgIndex
            if (n.bgImage != null) p[K.bgImage] = n.bgImage else p.remove(K.bgImage)
            p[K.cardSize] = n.cardSize
            p[K.showClock] = n.showClock
            p[K.clock24] = n.clock24
            p[K.bigClock] = n.bigClock
            p[K.showInputs] = n.showInputs
            p[K.showShortcuts] = n.showShortcuts
            p[K.rounded] = n.rounded
            p[K.favorites] = n.favorites.joinToString(",")
            p[K.hidden] = n.hidden
            p[K.renames] = encodeRenames(n.renames)
            p[K.sections] = n.sections.joinToString(",")
        }
    }
}
