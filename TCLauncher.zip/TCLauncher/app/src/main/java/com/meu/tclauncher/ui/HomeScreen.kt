package com.meu.tclauncher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.meu.tclauncher.LauncherViewModel
import com.meu.tclauncher.data.AppItem
import com.meu.tclauncher.data.LauncherPrefs
import com.meu.tclauncher.data.SECTION_NAMES

@Composable
fun HomeScreen(vm: LauncherViewModel, onOpenSettings: () -> Unit) {
    val ctx = LocalContext.current
    val prefs by vm.prefs.collectAsState()
    val apps by vm.apps.collectAsState()
    val inputs by vm.inputs.collectAsState()
    var menuApp by remember { mutableStateOf<AppItem?>(null) }
    var renameApp by remember { mutableStateOf<AppItem?>(null) }

    // Aplica os apelidos definidos pelo usuário; o app original não é alterado.
    val named = apps.map { a -> prefs.renames[a.pkg]?.let { a.copy(label = it) } ?: a }
    val visible = named.filter { it.pkg !in prefs.hidden }
    val favorites = prefs.favorites.mapNotNull { pkg -> visible.firstOrNull { it.pkg == pkg } }

    LauncherBackground(prefs) {
        Column(Modifier.fillMaxSize().padding(top = 24.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 48.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                FocusButton("⚙  Personalizar", prefs.accent, onClick = onOpenSettings)
                if (prefs.showClock) ClockView(prefs)
            }

            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 48.dp)) {
                prefs.sections.forEach { id ->
                    when (id) {
                        "inputs" -> if (prefs.showInputs && inputs.isNotEmpty()) {
                            item(key = id) {
                                Column {
                                    SectionTitle(SECTION_NAMES.getValue(id))
                                    LazyRow(contentPadding = PaddingValues(horizontal = 48.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                        items(inputs) { input ->
                                            Tile(input.label, null, false, prefs) { vm.launch(ctx, input.intent) }
                                        }
                                    }
                                }
                            }
                        }
                        "favorites" -> if (favorites.isNotEmpty()) {
                            item(key = id) {
                                Column {
                                    SectionTitle(SECTION_NAMES.getValue(id))
                                    AppRow(favorites, vm, ctx, prefs) { menuApp = it }
                                }
                            }
                        }
                        "apps" -> item(key = id) {
                            Column {
                                SectionTitle(SECTION_NAMES.getValue(id))
                                AppRow(visible, vm, ctx, prefs) { menuApp = it }
                            }
                        }
                        "shortcuts" -> if (prefs.showShortcuts) {
                            item(key = id) {
                                Column {
                                    SectionTitle(SECTION_NAMES.getValue(id))
                                    LazyRow(contentPadding = PaddingValues(horizontal = 48.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                        items(vm.shortcuts) { s ->
                                            Tile(s.label, null, false, prefs) { vm.launch(ctx, s.intent) }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        menuApp?.let { app ->
            AppMenu(
                app, vm, prefs.accent, app.pkg in prefs.favorites,
                onRename = { renameApp = app },
                onDismiss = { menuApp = null },
            )
        }
        renameApp?.let { app ->
            RenameDialog(app, prefs, onSave = { vm.rename(app.pkg, it) }, onDismiss = { renameApp = null })
        }
    }
}

@Composable
private fun AppRow(
    list: List<AppItem>,
    vm: LauncherViewModel,
    ctx: android.content.Context,
    prefs: LauncherPrefs,
    onMenu: (AppItem) -> Unit,
) {
    LazyRow(contentPadding = PaddingValues(horizontal = 48.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        items(list, key = { it.pkg }) { app ->
            Tile(app.label, app.icon, app.isBanner, prefs,
                onLongClick = { onMenu(app) }) { vm.launch(ctx, app.intent) }
        }
    }
}

@Composable
private fun AppMenu(
    app: AppItem, vm: LauncherViewModel, accent: Int, isFav: Boolean,
    onRename: () -> Unit, onDismiss: () -> Unit,
) {
    val ctx = LocalContext.current
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.clip(RoundedCornerShape(18.dp)).background(Color(0xFF1B1F2A)).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(app.label, color = Color.White, fontSize = 22.sp)
            FocusButton(if (isFav) "Remover dos favoritos" else "Adicionar aos favoritos", accent, Modifier.fillMaxWidth()) {
                vm.toggleFavorite(app.pkg); onDismiss()
            }
            if (isFav) {
                FocusButton("◀  Mover para a esquerda", accent, Modifier.fillMaxWidth()) { vm.moveFavorite(app.pkg, -1) }
                FocusButton("Mover para a direita  ▶", accent, Modifier.fillMaxWidth()) { vm.moveFavorite(app.pkg, 1) }
            }
            FocusButton("Renomear", accent, Modifier.fillMaxWidth()) { onRename(); onDismiss() }
            FocusButton("Ocultar da tela inicial", accent, Modifier.fillMaxWidth()) { vm.toggleHidden(app.pkg); onDismiss() }
            FocusButton("Informações do app", accent, Modifier.fillMaxWidth()) { vm.appInfo(ctx, app.pkg); onDismiss() }
            FocusButton("Desinstalar", accent, Modifier.fillMaxWidth()) { vm.uninstall(ctx, app.pkg); onDismiss() }
        }
    }
}

@Composable
private fun RenameDialog(app: AppItem, prefs: LauncherPrefs, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(app.label) }
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.clip(RoundedCornerShape(18.dp)).background(Color(0xFF1B1F2A)).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Novo nome do app", color = Color.White, fontSize = 22.sp)
            TextField(value = text, onValueChange = { text = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
            FocusButton("Salvar", prefs.accent, Modifier.fillMaxWidth()) { onSave(text); onDismiss() }
            FocusButton("Voltar ao nome original", prefs.accent, Modifier.fillMaxWidth()) { onSave(""); onDismiss() }
            FocusButton("Cancelar", prefs.accent, Modifier.fillMaxWidth()) { onDismiss() }
        }
    }
}
