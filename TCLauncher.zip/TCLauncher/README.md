# Meu Launcher (TCL Android TV)

Launcher personalizável em Kotlin + Jetpack Compose. É um app comum: não remove nem desativa nada da TV.
O launcher original da TCL continua instalado e você pode voltar a ele quando quiser.

## O que ele faz
- Tela inicial com: Entradas da TV (HDMI/AV/TV ao vivo, via TvInputManager), Favoritos, Todos os apps e Atalhos do sistema (Configurações, Wi-Fi, Bluetooth, Tela, Som, Todos os apps, Trocar launcher padrão).
- Personalização (botão "Personalizar"): temas prontos, cor de destaque, plano de fundo (gradientes ou imagem sua), tamanho dos cartões, cantos, relógio (24h e modo grande), mostrar/ocultar seções, ordem das seções e apps ocultos.
- Segure OK em um app: favoritar, mover, renomear (só no launcher, o app original não muda), ocultar, informações, desinstalar.
- Botão Voltar na tela inicial não faz nada (padrão de launchers).

## Compilar
Opção A, Android Studio: abra a pasta (Koala ou mais novo), aguarde o sync e use Build > Build APK(s). O APK sai em app/build/outputs/apk/debug/.

Opção B, sem instalar nada: crie um repositório no GitHub, envie esta pasta (inclui .github/workflows/build.yml), vá em Actions > Build APK > Run workflow e baixe o APK em "Artifacts" quando terminar.

## Instalar na TCL
1. Ative Opções do desenvolvedor e Depuração USB/ADB na TV.
2. `adb connect IP_DA_TV:5555` e depois `adb install app-debug.apk`.
3. Aperte Home. Se a TV perguntar qual launcher usar, escolha "Meu Launcher" (Sempre ou Só uma vez).
   Se não perguntar, abra Configurações > Apps > Apps padrão (ou o atalho "Trocar launcher padrão").

## Voltar ao launcher da TCL
Configurações > Apps > Apps padrão > Tela inicial, ou desinstale o app. Nada do sistema é alterado.

## Observações
- Alguns modelos TCL com Google TV podem não oferecer a troca de launcher; nesse caso o app continua acessível pela lista de apps.
- Banners e ícones vêm do próprio app instalado.
